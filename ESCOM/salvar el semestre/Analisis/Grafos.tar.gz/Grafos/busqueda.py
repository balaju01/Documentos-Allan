from Grafos.nodo import *
from Grafos.grafo import *


g = Grafo("Mi grafo 1")
print(g)

g.agregarNodo("r")
g.agregarNodo("s")
g.agregarNodo("t")
g.agregarNodo("u")
g.agregarNodo("v")
g.agregarNodo("w")
g.agregarNodo("x")
g.agregarNodo("y")

print(g)

print(g.obtenerNombresNodos())

r = g.obtenerNodo("r")
r.agregarVecino("s", 1)
r.agregarVecino("v", 1)

s = g.obtenerNodo("s")
s.agregarVecino("r", 1)
s.agregarVecino("w", 1)

t = g.obtenerNodo("t")
t.agregarVecino("u", 1)
t.agregarVecino("w", 1)
t.agregarVecino("x", 1)

u = g.obtenerNodo("u")
u.agregarVecino("t", 1)
u.agregarVecino("x", 1)
u.agregarVecino("y", 1)

v = g.obtenerNodo("v")
v.agregarVecino("r", 1)

w = g.obtenerNodo("w")
w.agregarVecino("s", 1)
w.agregarVecino("t", 1)
w.agregarVecino("x", 1)

x = g.obtenerNodo("x")
x.agregarVecino("t", 1)
x.agregarVecino("u", 1)
x.agregarVecino("w", 1)
x.agregarVecino("y", 1)

y = g.obtenerNodo("y")
y.agregarVecino("u", 1)
y.agregarVecino("x", 1)


print(r.obtenerVecinos())
print(s.obtenerVecinos())
print(t.obtenerVecinos())
print(u.obtenerVecinos())
print(v.obtenerVecinos())
print(w.obtenerVecinos())
print(x.obtenerVecinos())
print(y.obtenerVecinos())

g.imprimirNodos()

g.busquedaAmplitud("s")

g.imprimirNodos()

ruta = g.ruta("y", None)

print(ruta)

ruta2 = g.ruta("v", None)

print(ruta2)

g2 = Grafo("Mi grafo 2-> Busqueda en profundidad")

g2.agregarNodo("u")
g2.agregarNodo("v")
g2.agregarNodo("w")
g2.agregarNodo("x")
g2.agregarNodo("y")
g2.agregarNodo("z")

u = g2.obtenerNodo("u")
u.agregarVecino("v", 1)
u.agregarVecino("x", 1)

v = g2.obtenerNodo("v")
v.agregarVecino("y", 1)

w = g2.obtenerNodo("w")
w.agregarVecino("y", 1)
w.agregarVecino("z", 1)

x = g2.obtenerNodo("x")
x.agregarVecino("v", 1)

y = g2.obtenerNodo("y")
y.agregarVecino("x", 1)

g2.busquedaProfundidad("u")

print(g2)

g2.imprimirNodos()

ruta3 = g2.ruta("y", None)

print(ruta3)




















