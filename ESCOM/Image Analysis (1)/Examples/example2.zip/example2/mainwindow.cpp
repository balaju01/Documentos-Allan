#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "dlgimage.h"
#include <QMdiSubWindow>
#include <QFileDialog>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    mdiArea=new QMdiArea;
    setCentralWidget(mdiArea);

    connect(ui->actionOpen,SIGNAL(triggered()),this,SLOT(open()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::open() {
    QFileDialog seleccionaArchivo(this);
    QStringList archivos;
    QString archivo;


    seleccionaArchivo.setFileMode(QFileDialog::ExistingFile);
    seleccionaArchivo.setNameFilter(tr("Image (*.jpeg *.jpg *.png *.bmp)"));
    seleccionaArchivo.setAcceptMode(QFileDialog::AcceptOpen);

    if (seleccionaArchivo.exec()) {
        archivos=seleccionaArchivo.selectedFiles();
        archivo=archivos.at(0);
        ui->statusBar->showMessage(archivo,20000);

        dlgImage *i;
        i=new dlgImage(mdiArea);

        i->setPath(archivo);

        QMdiSubWindow *t=mdiArea->addSubWindow(i);
        t->widget()->adjustSize();
        i->show();
    }
}








