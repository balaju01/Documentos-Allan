#include "dlgimage.h"
#include "ui_dlgimage.h"

dlgImage::dlgImage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::dlgImage)
{
    ui->setupUi(this);
}

dlgImage::~dlgImage()
{
    delete ui;
}


void dlgImage::setPath(QString path) {
    QPixmap p;
    p.load(path);
    ui->img->setPixmap(p);
}
