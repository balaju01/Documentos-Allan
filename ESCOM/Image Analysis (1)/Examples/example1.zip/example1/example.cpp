#include "example.h"
#include "ui_example.h"

Example::Example(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Example)
{
    ui->setupUi(this);
}

Example::~Example()
{
    delete ui;
}

void Example::on_Button1_clicked()
{
    ui->label->setText("New text");
}
