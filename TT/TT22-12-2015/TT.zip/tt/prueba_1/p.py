#! /usr/bin/env python
from Crypto.Hash import SHA256
from Crypto.Cipher import AES
import random
hash = SHA256.new()
semilla=""
r=0
for i in range(5):
	r=random.randrange(100)
	semilla=semilla+chr(r)
	print str(i)+" "+str(r)+" "+chr(r)+" "+semilla
	
print semilla+"\n"


hash.update(semilla)
otra=hash.digest()
llave = ""
print otra


for i  in range(16):
	
	llave=llave+otra[i]
	print str(i)+" "+otra[i]+" "+llave
	
print "\n"
print llave


archi=open('Correo1.txt','r')
obj = AES.new(llave, AES.MODE_ECB)
lineas=archi.read(16)
ciphertext = obj.encrypt(lineas)
while lineas!="": 
	lineas=archi.read(16)
	if (len(lineas)==15):
		aux=lineas+" "
	else:
		aux=lineas
	ciphertext = obj.encrypt(aux)
	
	print lineas + "   "+str(len(lineas))+"   "+str(len(aux))+"   "+ciphertext
	


print "ok"

lineas="poiuytrewqasdfgh"
lineas=obj.encrypt(lineas)

print ciphertext
obj2 = AES.new(llave, AES.MODE_ECB)
desif=obj2.decrypt(lineas)
print desif
archi.close()
print "ok"

