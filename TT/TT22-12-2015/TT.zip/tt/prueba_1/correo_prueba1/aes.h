#ifndef AES_H
#define AES_H

class aes
{
public:
    aes();
private:
    void KeyExpansion(void);
};

#endif // AES_H
