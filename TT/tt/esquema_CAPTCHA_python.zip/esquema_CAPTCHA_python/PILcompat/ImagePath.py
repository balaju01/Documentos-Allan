from PIL.ImagePath import *
